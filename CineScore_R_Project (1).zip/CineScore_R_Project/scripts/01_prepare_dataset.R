# CineScore - Step 1: Build the 1,000-record dataset from REAL IMDb data
# Source: 'ggplot2movies' package (Hadley Wickham, GPL-3), which holds real IMDb
# movie records (up to 2005). The original file is kept in resources/.
# Run this script from the project folder (the one containing data/ and scripts/).

load("resources/imdb_movies_source.rda")        # loads object 'movies'
cat("Source records:", nrow(movies), "\n")

# Keep movies from 1980 onwards with at least 50 votes (reliable ratings)
pool <- subset(movies, year >= 1980 & votes >= 50)
cat("Records after filter:", nrow(pool), "\n")

set.seed(42)                                     # reproducible sample
cine <- pool[sample(nrow(pool), 1000),
             c("title","year","length","budget","votes","mpaa",
               "Action","Animation","Comedy","Drama","Documentary","Romance","Short","rating")]
write.csv(cine, "data/cinescore_1000.csv", row.names = FALSE)
cat("Saved data/cinescore_1000.csv with", nrow(cine), "rows\n")
