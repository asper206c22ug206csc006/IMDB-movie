# ==========================================================
# CineScore: Predictive Analytics of IMDb Movie Ratings (R)
# Models: Multiple Linear Regression and Random Forest
# Run from the project folder: source("scripts/02_cinescore_analysis.R")
# ==========================================================
library(ggplot2)
library(randomForest)

dir.create("outputs", showWarnings = FALSE)
sink("outputs/console_output.txt", split = TRUE)   # save console output to a file

# ---- 1. Load and inspect --------------------------------
cine <- read.csv("data/cinescore_1000.csv", stringsAsFactors = FALSE)
cat("===== 1. DATASET INSPECTION =====\n")
cat("Rows:", nrow(cine), " Columns:", ncol(cine), "\n\n")
cat("Column names:\n"); print(names(cine))
cat("\nFirst 6 rows:\n"); print(head(cine))
cat("\nStructure:\n"); str(cine)
cat("\nSummary:\n"); print(summary(cine[, c("year","length","budget","votes","rating")]))

# ---- 2. Cleaning and preprocessing ----------------------
cat("\n===== 2. DATA CLEANING =====\n")
cat("Missing values per column:\n"); print(colSums(is.na(cine)))
cat("Blank MPAA values:", sum(cine$mpaa == ""), "\n")
cat("Duplicate rows:", sum(duplicated(cine)), "\n")

# (a) Budget is missing for most movies: fill with median and add a flag column
cine$budget_known <- ifelse(is.na(cine$budget), 0, 1)
cine$budget[is.na(cine$budget)] <- median(cine$budget, na.rm = TRUE)
# (b) Blank MPAA means 'not rated' in this data
cine$mpaa[cine$mpaa == ""] <- "Unrated"
cine$mpaa <- factor(cine$mpaa)
# (c) Votes are highly skewed, so use log of votes
cine$log_votes <- log10(cine$votes)
# (d) Number of genres tagged for the movie
genre_cols <- c("Action","Animation","Comedy","Drama","Documentary","Romance","Short")
cine$genre_count <- rowSums(cine[, genre_cols])
cat("Missing values after cleaning:", sum(is.na(cine)), "\n")

model_data <- cine[, c("rating","year","length","budget","budget_known",
                       "log_votes","mpaa", genre_cols)]

# ---- 3. Exploratory Data Analysis -----------------------
cat("\n===== 3. EDA =====\n")
cat("Rating: mean =", round(mean(cine$rating), 2),
    " sd =", round(sd(cine$rating), 2),
    " min =", min(cine$rating), " max =", max(cine$rating), "\n")
num_cols <- c("rating","year","length","log_votes","budget")
cor_mat <- round(cor(cine[, num_cols]), 3)
cat("Correlation matrix:\n"); print(cor_mat)

theme_set(theme_minimal(base_size = 12))
ggsave_png <- function(p, name) ggsave(paste0("outputs/", name), p, width = 7, height = 4.5, dpi = 120)

p1 <- ggplot(cine, aes(rating)) + geom_histogram(bins = 25, fill = "#2E6F95", colour = "white") +
  labs(title = "Distribution of IMDb Ratings", x = "IMDb rating", y = "Number of movies")
ggsave_png(p1, "01_rating_histogram.png")

p2 <- ggplot(cine, aes(log_votes, rating)) + geom_point(alpha = 0.4, colour = "#2E6F95") +
  geom_smooth(method = "lm", colour = "#C0392B", se = FALSE) +
  labs(title = "Rating vs log10(Votes)", x = "log10(votes)", y = "IMDb rating")
ggsave_png(p2, "02_rating_vs_votes.png")

p3 <- ggplot(cine, aes(length, rating)) + geom_point(alpha = 0.4, colour = "#2E6F95") +
  geom_smooth(method = "lm", colour = "#C0392B", se = FALSE) + xlim(0, 250) +
  labs(title = "Rating vs Movie Length", x = "Length (minutes)", y = "IMDb rating")
ggsave_png(p3, "03_rating_vs_length.png")

# Average rating by genre (uses a for loop and a list)
genre_avg <- data.frame(genre = genre_cols, avg_rating = NA, n = NA)
for (i in seq_along(genre_cols)) {
  g <- genre_cols[i]
  genre_avg$avg_rating[i] <- round(mean(cine$rating[cine[[g]] == 1]), 2)
  genre_avg$n[i] <- sum(cine[[g]] == 1)
}
cat("\nAverage rating by genre:\n"); print(genre_avg)
p4 <- ggplot(genre_avg, aes(reorder(genre, avg_rating), avg_rating)) +
  geom_col(fill = "#2E6F95") + coord_flip() +
  labs(title = "Average Rating by Genre", x = NULL, y = "Average IMDb rating")
ggsave_png(p4, "04_rating_by_genre.png")

p5 <- ggplot(cine, aes(mpaa, rating)) + geom_boxplot(fill = "#A9CCE3") +
  labs(title = "Rating by MPAA Category", x = "MPAA", y = "IMDb rating")
ggsave_png(p5, "05_rating_by_mpaa.png")

# ---- 4. Train / test split (80:20) ----------------------
cat("\n===== 4. TRAIN/TEST SPLIT =====\n")
set.seed(123)
idx   <- sample(seq_len(nrow(model_data)), size = 0.8 * nrow(model_data))
train <- model_data[idx, ]
test  <- model_data[-idx, ]
cat("Training rows:", nrow(train), " Testing rows:", nrow(test), "\n")

# ---- 5. Evaluation function -----------------------------
evaluate <- function(actual, predicted) {
  rmse <- sqrt(mean((actual - predicted)^2))
  mae  <- mean(abs(actual - predicted))
  r2   <- 1 - sum((actual - predicted)^2) / sum((actual - mean(actual))^2)
  list(R2 = r2, RMSE = rmse, MAE = mae)
}

# ---- 6. Multiple Linear Regression ----------------------
cat("\n===== 5. MULTIPLE LINEAR REGRESSION =====\n")
lm_model <- lm(rating ~ ., data = train)
print(summary(lm_model))
lm_pred <- predict(lm_model, newdata = test)
# IMDb ratings are between 1 and 10, so keep predictions inside that range
lm_pred <- pmin(pmax(lm_pred, 1), 10)
lm_res  <- evaluate(test$rating, lm_pred)

# ---- 7. Random Forest Regression ------------------------
cat("\n===== 6. RANDOM FOREST REGRESSION =====\n")
set.seed(123)
rf_model <- randomForest(rating ~ ., data = train, ntree = 300, importance = TRUE)
print(rf_model)
rf_pred <- predict(rf_model, newdata = test)
rf_res  <- evaluate(test$rating, rf_pred)

# ---- 8. Model comparison --------------------------------
cat("\n===== 7. MODEL COMPARISON (test set) =====\n")
results <- data.frame(
  Model = c("Multiple Linear Regression", "Random Forest Regression"),
  R2    = round(c(lm_res$R2,   rf_res$R2),   4),
  RMSE  = round(c(lm_res$RMSE, rf_res$RMSE), 4),
  MAE   = round(c(lm_res$MAE,  rf_res$MAE),  4))
print(results)
write.csv(results, "outputs/model_comparison.csv", row.names = FALSE)
best <- results$Model[which.min(results$RMSE)]
cat("\nBest model (lowest RMSE):", best, "\n")

# ---- 9. Actual vs predicted -----------------------------
comp <- data.frame(Title = cine$title[-idx], Actual = test$rating,
                   LM_Predicted = round(lm_pred, 2), RF_Predicted = round(rf_pred, 2))
write.csv(comp, "outputs/actual_vs_predicted_test.csv", row.names = FALSE)
cat("\n===== 8. SAMPLE PREDICTIONS (first 10 test movies) =====\n")
print(head(comp, 10), row.names = FALSE)

long <- rbind(data.frame(Actual = test$rating, Predicted = lm_pred, Model = "Linear Regression"),
              data.frame(Actual = test$rating, Predicted = rf_pred, Model = "Random Forest"))
p6 <- ggplot(long, aes(Actual, Predicted)) + geom_point(alpha = 0.5, colour = "#2E6F95") +
  geom_abline(slope = 1, intercept = 0, colour = "#C0392B") + facet_wrap(~Model) +
  labs(title = "Actual vs Predicted IMDb Rating (Test Set)")
ggsave("outputs/06_actual_vs_predicted.png", p6, width = 8, height = 4.2, dpi = 120)

# Residual plot for the linear model (statistical check)
rd <- data.frame(Fitted = fitted(lm_model), Residual = resid(lm_model))
p7 <- ggplot(rd, aes(Fitted, Residual)) + geom_point(alpha = 0.4, colour = "#2E6F95") +
  geom_hline(yintercept = 0, colour = "#C0392B") +
  labs(title = "Linear Model Residuals (Training Data)")
ggsave_png(p7, "07_lm_residuals.png")

# Random Forest variable importance
imp <- importance(rf_model)[, "%IncMSE"]
imp_df <- data.frame(Variable = names(imp), Importance = as.numeric(imp))
cat("\nRandom Forest variable importance (%IncMSE):\n")
print(imp_df[order(-imp_df$Importance), ], row.names = FALSE)
p8 <- ggplot(imp_df, aes(reorder(Variable, Importance), Importance)) +
  geom_col(fill = "#2E6F95") + coord_flip() +
  labs(title = "Random Forest Variable Importance", x = NULL, y = "%IncMSE")
ggsave_png(p8, "08_rf_importance.png")

# ---- 10. Predict a new movie ----------------------------
cat("\n===== 9. PREDICT A NEW (EXAMPLE) MOVIE =====\n")
new_movie <- data.frame(year = 2003, length = 120, budget = median(cine$budget),
                        budget_known = 0, log_votes = 4, mpaa = factor("PG-13", levels = levels(train$mpaa)),
                        Action = 1, Animation = 0, Comedy = 0, Drama = 1,
                        Documentary = 0, Romance = 0, Short = 0)
cat("Example input: 2003, 120 min, ~10,000 votes, PG-13, Action+Drama\n")
cat("Linear Regression prediction:", round(predict(lm_model, new_movie), 2), "\n")
cat("Random Forest prediction    :", round(predict(rf_model, new_movie), 2), "\n")

cat("\nSession info:", R.version.string, "\n")
sink()
