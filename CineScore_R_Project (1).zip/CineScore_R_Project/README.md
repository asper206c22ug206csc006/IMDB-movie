# CineScore: Predictive Analytics of IMDb Movie Ratings Using Regression Models in R

Mini project - 23CAP317 R Programming (MCA, Karpagam College of Engineering)

## What this project does
Predicts the IMDb rating of a movie from its year, length, budget, number of votes,
MPAA category and genres, using **Multiple Linear Regression** and **Random Forest Regression**.

## Dataset (real data, not synthetic)
- Source: `ggplot2movies` R package (Hadley Wickham, GPL-3). It contains real IMDb records (movies up to 2005).
- The original file is included: `resources/imdb_movies_source.rda` (58,788 movies).
- `scripts/01_prepare_dataset.R` keeps movies from 1980 onwards with at least 50 votes (13,856 movies),
  then randomly samples **1,000** with `set.seed(42)` -> `data/cinescore_1000.csv`.
- Note: this is a 2005-era snapshot, so the model predicts ratings of older movies, not today's releases.

## Folder structure
| Folder / file | Contents |
|---|---|
| `data/` | `cinescore_1000.csv` - the 1,000-record dataset |
| `scripts/` | `01_prepare_dataset.R`, `02_cinescore_analysis.R` |
| `outputs/` | 8 graphs (PNG), `console_output.txt`, `model_comparison.csv`, `actual_vs_predicted_test.csv` |
| `screenshots/` | Images of the real R console output (see note below) |
| `resources/` | Original IMDb source data |
| `report/` | `CineScore_Report.docx` - short project report |

## How to run in RStudio
1. Unzip the project and open RStudio.
2. Set the working directory to the unzipped folder: `Session > Set Working Directory > Choose Directory`
   (or `setwd("path/to/CineScore_R_Project")`).
3. Install packages once: `install.packages(c("ggplot2", "randomForest"))`
4. Run `source("scripts/02_cinescore_analysis.R")` (the dataset is already included).
   Optional: run `source("scripts/01_prepare_dataset.R")` first to rebuild the CSV.
5. Results appear in the console and are saved in the `outputs/` folder.

## Actual results (test set, 200 movies)
| Model | R2 | RMSE | MAE |
|---|---|---|---|
| Multiple Linear Regression | 0.2645 | 1.1820 | 0.9555 |
| Random Forest Regression | 0.3890 | 1.0772 | 0.8566 |

Random Forest performed better. Both models explain only part of the variation, because
IMDb ratings also depend on things not in this data (cast, story, director).

## Honest notes
- Everything was run in R 4.3.3; all numbers above come from that run (`outputs/console_output.txt`).
- Linear Regression predictions are limited to the 1-10 rating range (one raw prediction was above 13).
- The files in `screenshots/` are images rendered from the real console output text
  (`console_output.txt`). They are not window captures of RStudio, because the project was run
  on a server without a screen. Running the script in RStudio gives the same output.
- The data is not time-based, so a random 80:20 split was used (seeds 42 and 123).
